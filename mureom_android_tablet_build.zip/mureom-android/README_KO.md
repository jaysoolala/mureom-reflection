# 의식성찰 : 머물다 — Android 프로젝트

이 프로젝트는 전달해 주신 HTML 앱을 Android WebView 앱 안에 포함한 개인용 APK 제작용 프로젝트입니다.

## 현재 포함된 기능
- 기존 여섯 묵상 항목과 미니멀 디자인
- WebView 로컬 저장소(localStorage)를 이용한 날짜별 자동 저장
- 지난 기록, 이어 쓰기, 하루 돌아보기
- Android 시스템 저장 위치를 선택하는 JSON 백업
- Android 파일 선택기를 통한 JSON 백업 복원
- 앱 아이콘/이름으로 실행하는 Android 앱 골격

## APK 만들기
1. 컴퓨터에 Android Studio 최신 안정 버전을 설치합니다.
2. Android Studio에서 이 폴더 `MureomReflection`을 엽니다.
3. Gradle 동기화가 끝날 때까지 기다립니다. JDK 17 이상과 Android SDK 35가 필요합니다.
4. 상단 메뉴 **Build > Build Bundle(s) / APK(s) > Build APK(s)** 를 선택합니다.
5. 생성된 APK는 `app/build/outputs/apk/debug/app-debug.apk`에 있습니다.
6. 본인 기기에 설치해 테스트합니다. 배포용 서명 APK/AAB는 Android Studio의 **Build > Generate Signed Bundle / APK**에서 별도 생성합니다.

## 중요한 사항
- 이 실행 환경에는 Android SDK와 Gradle 빌드 도구가 없어 APK 바이너리를 직접 컴파일하지 않았습니다. 이 압축 파일은 Android Studio에서 빌드할 수 있는 프로젝트 소스입니다.
- 앱 ID는 `com.mureom.reflection`으로 설정했습니다. 플레이스토어에 처음 등록한 뒤에는 앱 ID를 바꾸기 어렵기 때문에, 공개 배포 전 고유한 ID인지 확인해야 합니다.
- 기록은 현재 앱 설치본의 WebView 로컬 저장소에 저장됩니다. 앱을 삭제하거나 앱 데이터/저장공간을 지우면 기록이 사라질 수 있으므로 정기적으로 JSON 백업을 보관하세요.
- HTML 폰트는 Google Fonts에서 가져오므로 인터넷이 없으면 기기 기본 글꼴로 대체될 수 있습니다. 앱의 기록 기능은 로컬에서 동작합니다.
- Play 스토어 배포 전에는 앱 아이콘, 개인정보처리방침, 데이터 보안 설문, 서명 키, 대상 API 요구사항, 실제 기기 테스트를 추가로 점검해야 합니다.
- 백업 복원 시 동일 날짜의 기존 기록은 백업 파일의 내용으로 덮어씁니다.


## 태블릿만으로 APK 만들기 (GitHub Actions)
1. 태블릿 브라우저에서 GitHub 계정을 만들거나 로그인합니다.
2. 새 저장소(repository)를 만들고 이름을 `mureom-reflection`으로 지정합니다. 공개/비공개는 편한 쪽을 선택합니다.
3. 이 ZIP을 태블릿에서 압축 해제한 뒤, 안의 파일과 폴더를 저장소에 업로드합니다. `.github` 폴더도 포함해야 합니다.
4. 저장소의 **Actions** 탭에서 `Build Android APK`를 선택하고 **Run workflow**를 누릅니다. (처음에는 GitHub가 Actions 사용을 허용하도록 물을 수 있습니다.)
5. 작업이 초록색 체크 표시로 끝나면 해당 실행 기록을 열고 아래 **Artifacts**에서 `mureom-reflection-debug-apk`를 눌러 다운로드합니다.
6. 내려받은 ZIP을 풀어 `app-debug.apk`를 누르고 설치합니다. 설치가 막히면 Android 설정에서 해당 브라우저/파일 앱의 '알 수 없는 앱 설치 허용'을 켠 뒤 다시 설치합니다.
7. 이 APK는 개인 테스트용 debug 빌드입니다. Play 스토어 배포 전에는 별도의 서명 키로 release AAB를 만들고, 앱 ID와 개인정보/데이터 안전 관련 항목을 검토해야 합니다.

주의: GitHub 계정과 인터넷 연결이 필요합니다. Actions의 실행 로그와 저장소에 개인 묵상 내용을 올리지 마세요. 이 저장소에는 앱 소스만 올리고, 실제 묵상 기록 백업 파일은 업로드하지 마세요.
